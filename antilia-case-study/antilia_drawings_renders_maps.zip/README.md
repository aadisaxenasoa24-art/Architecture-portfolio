# Drawings, renders and historic maps

- plate_figure_ground / plate_movement / plate_open_space / plate_heights (PNG, 1400 px): 1 km plates drawn from OpenStreetMap (ODbL). In plate_heights, white hatching marks estimated heights.
- section_west_east.svg: 2 km west-east section through Antilia, vertical scale x1.9 (editable in Illustrator).
- deck_* and cover (PNG): renders of the 1 km model (white = height from data, grey = estimated, terracotta = Antilia).
- cook1887_cumballa.jpg: Cook's Plan of Bombay, 1887 (Harvard College Library), public domain. The dashed circle is Antilia's approximate site (placed by distance from Gowalia Tank and Grant Road, +/-150 m).
- map1909_cumballa.jpg: J. G. Bartholomew, Gazetteer of Bombay City and Island, 1909, public domain (Wikimedia Commons crop; the red arrow is the uploader's).
- baxter1882.jpg: W. E. Baxter, "Bombay, view from Cumballa Hill", A Winter in India, 1882 (British Library), public domain.
Credit "(c) OpenStreetMap contributors" wherever the plates or renders appear.
