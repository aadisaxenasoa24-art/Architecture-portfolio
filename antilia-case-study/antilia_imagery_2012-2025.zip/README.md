# Antilia site imagery, 2012-2025

Centre: Antilia footprint centroid, 18.968080 N, 72.809599 E. North up, Web Mercator.
Context frames (wb_ctx_*): 2,500 m square (1,250 m each side of the tower), 1600 px. Site frames (wb_site_*): 440 m square.
Sentinel-2 frames (s2_*): 2,500 m square, 10 m source resolution.

File name dates are Esri archive RELEASE dates. The capture dates are below. Use the capture date in captions.

| File date (release) | Captured | Sensor | Provider | Source resolution | Credit |
|---|---|---|---|---|---|
| 2014-02-20 | 2012-05-03 | WorldView-2 | DigitalGlobe | 0.5 m | Esri World Imagery Wayback, release 2014-02-20; source DigitalGlobe WorldView-2, captured 2012-05-03 |
| 2015-03-18 | 2013-04-03 | Pleiades | CNES/Airbus DS | 0.5 m | Esri World Imagery Wayback, release 2015-03-18; source CNES/Airbus DS Pleiades, captured 2013-04-03 |
| 2017-03-15 | 2016 (year only) | WorldView-2 | DigitalGlobe | 0.5 m | Esri World Imagery Wayback, release 2017-03-15; source DigitalGlobe WorldView-2, captured 2016 (year only) |
| 2020-03-23 | 2018-10-25 | WorldView-4 | Maxar | 0.31 m | Esri World Imagery Wayback, release 2020-03-23; source Maxar WorldView-4, captured 2018-10-25 |
| 2020-07-01 | 2020-01-30 | WorldView-3 | Maxar | 0.31 m | Esri World Imagery Wayback, release 2020-07-01; source Maxar WorldView-3, captured 2020-01-30 |
| 2022-03-16 | 2021-10-29 | WorldView-2 | Maxar | 0.5 m | Esri World Imagery Wayback, release 2022-03-16; source Maxar WorldView-2, captured 2021-10-29 |
| 2022-08-10 | 2022-02-14 | WorldView-3 | Maxar | 0.31 m | Esri World Imagery Wayback, release 2022-08-10; source Maxar WorldView-3, captured 2022-02-14 |
| 2023-05-03 | 2022-12-27 | WorldView-3 | Maxar | 0.31 m | Esri World Imagery Wayback, release 2023-05-03; source Maxar WorldView-3, captured 2022-12-27 |
| 2024-08-15 | 2024-01-17 | GeoEye-1 | Maxar | 0.46 m | Esri World Imagery Wayback, release 2024-08-15; source Maxar GeoEye-1, captured 2024-01-17 |
| 2025-06-26 | 2025-04-14 | WorldView-2 | Maxar | 0.5 m | Esri World Imagery Wayback, release 2025-06-26; source Maxar WorldView-2, captured 2025-04-14 |
| 2026-03-26 | 2025-11-15 | Legion-1 | Vantor | 0.34 m | Esri World Imagery Wayback, release 2026-03-26; source Vantor Legion-1, captured 2025-11-15 |

Sentinel-2 cloudless annual mosaics: https://s2maps.eu by EOX IT Services GmbH (contains modified Copernicus Sentinel data, year as in file name). 2016: CC BY 4.0; 2019 onward: CC BY-NC-SA 4.0.

Licence note: Esri World Imagery is under the Esri Master License Agreement, not an open licence. Use these frames for study and presentation with the credit line, and do not redistribute them as data.
The 2012 site close-up is upsampled from zoom 17 (about 1.1 m per pixel); finer tiles do not exist for that capture.
Towers lean away from the satellite in close-ups (relief displacement), so roofs sit off their footprints and the lean changes between captures.