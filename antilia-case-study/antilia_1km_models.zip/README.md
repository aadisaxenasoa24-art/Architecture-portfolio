# Antilia — 1 km context model

Site: Antilia, Altamount Road (S. K. Barodawala Marg), Cumballa Hill, Mumbai 400026.
Model origin (0,0,0) = centroid of Antilia's OpenStreetMap footprint (way 48743709):
lat 18.968080 N, lon 72.809599 E. Units: metres. x = east, y = north, z = metres above sea level (approx.).
Projection: transverse Mercator centred on the origin (+proj=tmerc +lat_0=18.96807959562193 +lon_0=72.80959875160038 +k=1 +x_0=0 +y_0=0 +ellps=WGS84).
Extent: circle of radius 1,000 m (rings at 250 / 500 / 1,000 m are included).

## Files
| File | Use |
|---|---|
| antilia_1km_context.3dm | Rhino 8 (saved as v8). Layers below. Every building is a separate closed mesh with User Text: osm_id, name, height_m, height_source, osm_levels, ground_m_approx, dist_from_antilia_m (Properties > Attribute User Text; Grasshopper: Get User Text). |
| antilia_1km_context.obj + .mtl | Any 3D package. z-up, metres, one group per layer. In Rhino use Import, units = metres. In SketchUp/Blender choose z-up. |
| antilia_1km_context.glb | glTF binary (y-up), for Blender, web viewers, Twinmotion/D5 via import. |
| antilia_1km_siteplan.dxf | 2D site plan for AutoCAD/Illustrator: footprints, road edges, rail, green, water, coast, rings, labels (metres). |
| antilia_site_google_earth.kml | Opens Google Earth Pro on the site with the footprint and 500 m / 1 km rings. Use View > Historical Imagery for frames before 2012 (orphanage plot, 2006-2010 construction). |
| antilia_1km_buildings.csv | Table of every building with height and source. |

## Rhino layers
01_ANTILIA · 02_Buildings_height_from_data · 03_Buildings_height_estimated · 04_Roads_major/minor/service/foot · 05_Roads_flyovers · 06_Rail (+ platforms) · 07_Green_open_space · 08_Water_pools · 09_Sea · 10_Terrain · 11_Base_skirt (to -30 m) · 20_PLAN_2D_footprints · 21_PLAN_2D_road_edges · 22_PLAN_2D_coastline · 23_Rings_250_500_1000m · 24_Labels (text dots) · 25_North_arrow

Tips: for a clean figure-ground use layers 20-23 only (they sit at z = 0). For Make2D axonometrics, hide 10/11 and run Make2D on 01-07. Antilia is 173 m: set a clipping plane at roof height (≈225 m ASL) to cut sections through the ridge.

## How heights were assigned (read before you quote a neighbour's height)
1. Published figure (CTBUH / SkyscraperPage / engineer): Antilia 173 m; Lodha Altamount 195 m; The Imperial I & II 210 m roof (256 m to spire); Iora 195 m; Shreepati Arcade 152.5 m; Le Palazzo 150 m (unconfirmed); Kanchanjunga 84 m; Usha Kiran 80 m. Sources in the CSV column height_ref.
2. OpenStreetMap `height` tag, or `building:levels` x 3.2 m.
3. Otherwise ESTIMATED from the EU JRC GHSL GHS-BUILT-H ANBH 2018 grid (average net building height per 100 m cell), capped at the 90th percentile of tagged buildings with a similar footprint area.
Estimated buildings are on layer 03 and carry height_source = ghsl_est (or default_est). About 71% of buildings are estimated. Treat their heights as indicative massing, not survey data.

## Terrain
AWS Terrain Tiles (Mapzen terrarium, zoom 15; SRTM-derived), smoothed (gaussian, about 40 m). SRTM is a surface model (2000) that includes trees/buildings, so ground levels may read high by several metres; treat as +/-10 m. The sea surface is z = 0.

## Sources and licences
- Footprints, roads, rail, green space, water, coastline: (c) OpenStreetMap contributors, ODbL 1.0 — https://www.openstreetmap.org/copyright (extract downloaded 1 Oct 2026). Credit "(c) OpenStreetMap contributors" wherever you show the model.
- Heights (estimates): European Commission, Joint Research Centre — GHSL GHS-BUILT-H R2023A (ANBH, epoch 2018, 100 m), CC BY 4.0.
- Terrain: AWS Terrain Tiles / Mapzen (SRTM, NASA/USGS, public domain).
Built with Python (shapely, pyproj, rhino3dm, trimesh, ezdxf).

## Google Earth Pro: imagery before 2012 (the orphanage plot and construction years)
1. Open antilia_site_google_earth.kml in Google Earth Pro (desktop). It flies to the site and draws the footprint and the 500 m / 1 km rings.
2. View > Historical Imagery (clock icon). Step the slider back through the dates Google offers for this point.
3. For each frame you use, note the date shown in the status bar and the provider credit printed on screen (for example "Imagery (c) Maxar"). Google's imagery is copyrighted: use it for study with that credit, and do not redistribute it.
4. Targets: the orphanage plot before 2006; excavation and frame 2006-2009; completion 2010. Which dates exist for this point is not documented anywhere I could find, so record what you see.
